'''
Plot some basic survival statistics for the titanic data
'''
print(__doc__)

from titanic import data, outcomes
from visualizations import survival_stats
# Plot-1
# Plot how many men and women has survived
survival_stats(data, outcomes, 'Sex');



# Plot - 2
# X-axis is the age  
survival_stats(data, outcomes, 'Age', ["Sex == 'male'"]);

# Plot - 3
# X axis is the passenger class
survival_stats(data, outcomes, 'Pclass');


#Plot -4
survival_stats(data,outcomes,'Parch');

# Plot-5
survival_stats(data,outcomes,'SibSp');
